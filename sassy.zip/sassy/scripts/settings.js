export function register_settings() {
    //TBD
}